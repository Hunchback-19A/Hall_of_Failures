# Release zip checklist

Use this when you build a **zipped release** by hand (or when checking what GitHub’s source zip should contain).

This is **not** the feature list. Feature / version notes live in [`CHANGELOG.md`](CHANGELOG.md).

---

## Pack these (required)

```text
MegaDateTime/
├── LICENSE                 # MIT license
├── README.md
├── CHANGELOG.md
├── RELEASE_CHECKLIST.md    # this file (optional but useful)
├── pyproject.toml
├── megadatetime/
│   ├── __init__.py
│   ├── mega_datetime.py
│   ├── satellite_time.py
│   ├── earth_rotation.py
│   └── _http.py
├── EarthViewer/
│   ├── __init__.py
│   ├── main.py
│   ├── config.py
│   ├── fetch_textures.py
│   ├── requirements.txt
│   ├── README.md
│   ├── renderer/
│   │   ├── __init__.py
│   │   ├── earth.py
│   │   ├── camera.py
│   │   ├── layers.py
│   │   └── textures.py
│   ├── time/
│   │   ├── __init__.py
│   │   └── earth_time.py
│   └── data/
│       ├── textures/.gitkeep
│       └── satellite/.gitkeep
└── tests/
    ├── test_mega_datetime.py
    ├── test_satellite_time.py
    ├── test_earth_rotation.py
    ├── test_earth_viewer.py
    └── fixtures/
        ├── timeapi_utc.json
        └── finals2000A.daily.csv
```

**Quick count:** docs + `pyproject.toml` + `megadatetime/` + `EarthViewer/` (code) + `tests/` (+ empty `data/` keep files).

---

## Optional (nice to include)

| Item | Why |
| --- | --- |
| `EarthViewer/data/textures/earth_day.jpg` | Realistic globe (users can also run `python -m EarthViewer.fetch_textures`) |
| `EarthViewer/data/textures/earth_night.jpg` | Same |
| `EarthViewer/data/textures/earth_clouds.jpg` | Same |

Leave textures out if you want a **small** zip; the viewer still runs with procedural placeholders.

---

## Do **not** pack

| Skip | Why |
| --- | --- |
| `__pycache__/` | Generated junk |
| `.pytest_cache/` | Generated junk |
| `megadatetime.egg-info/` | Local install metadata |
| `.git/` | Not needed inside the zip |
| Virtual env folders (`venv/`, `.venv/`) | Recreated with pip |
| Editor folders (`.idea/`, `.vscode/`) | Personal |

---

## After zipping — smoke check

1. Unzip into a **new** empty folder  
2. `pip install -e ".[dev]"`  
3. `pytest`  
4. (Optional) `pip install -e ".[viewer]"` then `python -m EarthViewer.main`

If those work, the zip is complete.
